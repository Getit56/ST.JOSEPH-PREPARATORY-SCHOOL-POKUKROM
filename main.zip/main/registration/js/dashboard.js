// -------------------- Firebase Setup --------------------
var firebaseConfig = {
  apiKey: "AIzaSyAoSRm7DKQB0bTRCKNELxbEVQA7y0hGgT4",
  authDomain: "school-registration-a9774.firebaseapp.com",
  databaseURL: "https://school-registration-a9774-default-rtdb.firebaseio.com",
  projectId: "school-registration-a9774",
  storageBucket: "school-registration-a9774.appspot.com",
  messagingSenderId: "967547068125",
  appId: "1:967547068125:web:0a5708c69c84d1bac64534"
};

firebase.initializeApp(firebaseConfig);
var database = firebase.database();
var studentsRef = database.ref('students');

// -------------------- DOM Elements --------------------
var tableBody = document.querySelector('#studentsTable tbody');
var searchName = document.getElementById('searchName');
var filterGender = document.getElementById('filterGender');
var filterReligion = document.getElementById('filterReligion');
var filterDenomination = document.getElementById('filterDenomination');
var filterClass = document.getElementById('filterClass');
var filterRegion = document.getElementById('filterRegion');
var filterAge = document.getElementById('filterAge');
var filterEmergency = document.getElementById('filterEmergency');
var clearFiltersBtn = document.getElementById('clearFilters');

var totalStudentsElem = document.getElementById('totalStudents');
var totalMalesElem = document.getElementById('totalMales');
var totalFemalesElem = document.getElementById('totalFemales');
var filteredResultsElem = document.getElementById('filteredResults');

var allStudents = [];

// NEW: Add Student DOM Elements
var toggleAddStudentFormBtn = document.getElementById('toggleAddStudentForm');
var addStudentSection = document.getElementById('addStudentSection');
var addStudentForm = document.getElementById('addStudentForm');
var regDenominationSelect = document.getElementById('regDenomination');
var regDenominationCustom = document.getElementById('regDenominationCustom');
var regNationalitySelect = document.getElementById('regNationality');
var regNationalityCustom = document.getElementById('regNationalityCustom');


// -------------------- Helper Functions --------------------

// Helper function to calculate age from DOB
function calculateAge(dobString) {
    if (!dobString) return 'N/A';
    const dob = new Date(dobString);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
        age--;
    }
    return age;
}

// Define options based on index.html
const classOptions = ["Nursery 1", "Nursery 2", "KG 1", "KG 2", "Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6", "JHS 1", "JHS 2", "JHS 3"];
const genderOptions = ["Male", "Female"];
const religionOptions = ["Christian", "Muslim", "Traditional", "None"];
const denominationOptions = ["Catholic", "Pentecost", "Other"];
const regionOptions = ["Ashanti", "Greater Accra", "Central", "Volta", "Eastern", "Western", "Northern", "Upper East", "Upper West", "North East", "Oti", "Ahafo", "Western North", "Savannah", "Bono East", "Bono"];

// Function to generate a <select> element HTML
function generateSelect(field, currentValue, options, isRequired = false) {
    let html = `<select data-field="${field}" ${isRequired ? 'required' : ''}>`;
    // Add default empty option if the value isn't set
    if (!currentValue && (field === 'classApplying' || field === 'gender' || field === 'region')) {
        html += `<option value="" selected>${field === 'region' ? 'Select Region' : 'Select option'}</option>`;
    } else {
        html += `<option value="">Select option</option>`; // Always include an empty option
    }

    options.forEach(option => {
        const value = option;
        const selected = (value === currentValue) ? 'selected' : '';
        // Skip the default empty option if an actual value is found
        if (value !== "") {
           html += `<option value="${value}" ${selected}>${option}</option>`;
        }
    });
    html += `</select>`;
    return html;
}


// -------------------- Table Edit Functions (UPDATED) --------------------

// Function to switch a row from display to edit mode (REQUIRED ATTRIBUTE REMOVED)
function editStudent(button, studentKey) {
    const row = button.closest('tr');
    // Prevent editing if another row is already in edit mode
    if (document.querySelector('tr[data-editing="true"]')) {
        alert("Please save or cancel the current edit before starting a new one.");
        return;
    }

    const student = allStudents.find(s => s.key === studentKey);
    if (!student) {
        alert("Error: Student data not found.");
        return;
    }

    row.setAttribute('data-editing', 'true');
    const cells = row.querySelectorAll('td');

    // 0. Name (firstName, middleName, surname) - No required attribute
    cells[0].innerHTML = `
        <label>First Name</label><input type="text" data-field="firstName" value="${student.firstName || ''}" placeholder="First Name">
        <label>Middle Name</label><input type="text" data-field="middleName" value="${student.middleName || ''}" placeholder="Middle Name" />
        <label>Surname</label><input type="text" data-field="surname" value="${student.surname || ''}" placeholder="Surname">
    `;

    // 1. Class (classApplying) - isRequired set to false
    cells[1].innerHTML = generateSelect('classApplying', student.classApplying, classOptions, false);

    // 2. Age (DOB input for deriving age)
    cells[2].innerHTML = `
        <label>DOB</label><input type="date" data-field="dob" value="${student.dob || ''}" />
        <p style="font-size: 0.8em; margin: 0;">Current Age: ${calculateAge(student.dob)}</p>
    `;

    // 3. Gender (gender) - isRequired set to false
    cells[3].innerHTML = generateSelect('gender', student.gender, genderOptions, false);

    // 4. Religion (religion)
    cells[4].innerHTML = generateSelect('religion', student.religion, religionOptions);

    // 5. Denomination (denomination + custom input if "Other")
    const currentDenomination = student.denomination || '';
    const isCustomDenomination = denominationOptions.indexOf(currentDenomination) === -1 && currentDenomination !== 'Catholic' && currentDenomination !== 'Pentecost' && currentDenomination !== '';
    const initialDenomSelect = isCustomDenomination ? 'Other' : currentDenomination;
    const initialDenomCustom = isCustomDenomination ? currentDenomination : '';
    
    cells[5].innerHTML = `
        <label>Denomination</label>${generateSelect('denomination', initialDenomSelect, denominationOptions)}
        <input type="text" data-field="denominationCustom" value="${initialDenomCustom}" placeholder="Type if Other" style="${initialDenomSelect !== 'Other' ? 'display: none; margin-top:5px;' : 'margin-top:5px;'}" />
    `;
    // Add listener to show/hide custom input
    const denomSelect = cells[5].querySelector('select[data-field="denomination"]');
    const denomCustom = cells[5].querySelector('input[data-field="denominationCustom"]');
    if (denomSelect && denomCustom) {
        denomSelect.addEventListener('change', () => {
            denomCustom.style.display = denomSelect.value === 'Other' ? 'block' : 'none';
        });
    }

    // 6. Guardian (guardianName) - No required attribute
    cells[6].innerHTML = `<input type="text" data-field="guardianName" value="${student.guardianName || ''}" placeholder="Guardian Name">`;

    // 7. Phone (phone)
    cells[7].innerHTML = `<input type="tel" data-field="phone" value="${student.phone || ''}" placeholder="Phone Number" />`;

    // 8. Town / Region (town, region)
    cells[8].innerHTML = `
        <label>Town</label><input type="text" data-field="town" value="${student.town || ''}" placeholder="Town / City" />
        <label>Region</label>${generateSelect('region', student.region, regionOptions)}
    `;

    // 9. Date Registered (registrationDate)
    cells[9].innerHTML = `<input type="date" data-field="registrationDate" value="${student.registrationDate || ''}" />`;

    // 10. Actions
    cells[10].innerHTML = `
        <button onclick="saveChanges(this, '${studentKey}')" class="save-btn">Save</button>
        <button onclick="cancelEdit(this)" class="cancel-btn">Cancel</button>
    `;
}

// Function to save changes back to Firebase (MODIFIED FOR CONFIRMATION)
function saveChanges(button, studentKey) {
    // 1. ADD CONFIRMATION DIALOG
    if (!confirm("Are you sure you want to save these changes?")) {
        return; // Stop the function if the user cancels
    }

    const row = button.closest('tr');
    const inputs = row.querySelectorAll('input, select');
    const updateData = {};
    
    // Remove previous error styles
    row.querySelectorAll('input, select').forEach(el => el.style.border = '');

    // Collect data (without required field validation)
    inputs.forEach(input => {
        const field = input.getAttribute('data-field');
        if (field) {
            updateData[field] = input.value;
        }
    });

    // Handle Denomination Custom Field logic
    if (updateData.denomination === 'Other' && updateData.denominationCustom) {
        updateData.denomination = updateData.denominationCustom;
    }
    delete updateData.denominationCustom; // Remove the temp custom field

    // Visual feedback during save
    row.setAttribute('data-editing', 'saving');
    button.closest('td').innerHTML = 'Saving...';
    
    // Update Age property based on new DOB
    if (updateData.dob) {
        updateData.age = calculateAge(updateData.dob);
    }
    
    // --- Update Firebase ---
    studentsRef.child(studentKey).update(updateData)
        .then(() => {
            alert("Student details updated successfully!");
            // Re-render the whole table to exit edit mode and display new data
            applyFilters();
        })
        .catch(error => {
            alert("Error updating data: " + error.message);
            console.error("Firebase update failed:", error);
            // Re-render the table on error to restore original state
            applyFilters();
        });
}

// Function to cancel editing
function cancelEdit(button) {
    // Simply re-render the entire filtered table to exit edit mode and restore original data.
    applyFilters(); 
}

// -------------------- Render Table (UPDATED to include key and Actions) --------------------
function renderTable(students) {
  tableBody.innerHTML = '';

  // Colspan updated to 11 (10 data columns + 1 Actions column)
  if (students.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="11" style="text-align:center;">No students found</td></tr>';
    return;
  }

  students.forEach(function(student) {
    // Calculate age if not present or dob is updated
    const studentAge = student.age || calculateAge(student.dob);

    var row = document.createElement('tr');
    // Store the Firebase key on the row element
    row.setAttribute('data-key', student.key); 
    
    // The Edit button calls the new editStudent function, passing itself and the key
    var actionsColumn = `<td><button onclick="editStudent(this, '${student.key}')" class="edit-btn">Edit</button></td>`;

    row.innerHTML = '<td>' + (student.firstName || '') + ' ' + (student.middleName ? student.middleName + ' ' : '') + (student.surname || '') + '</td>' +
                    '<td>' + (student.classApplying || '') + '</td>' +
                    '<td>' + studentAge + '</td>' + // Display Age
                    '<td>' + (student.gender || '') + '</td>' +
                    '<td>' + (student.religion || '') + '</td>' +
                    '<td>' + (student.denomination || '') + '</td>' +
                    '<td>' + (student.guardianName || '') + '</td>' +
                    '<td>' + (student.phone || '') + '</td>' +
                    '<td>' + (student.town || '') + ' / ' + (student.region || '') + '</td>' +
                    '<td>' + (student.registrationDate || '') + '</td>' +
                    actionsColumn;
    tableBody.appendChild(row);
  });
}

// -------------------- Apply Filters (No Change) --------------------
function applyFilters() {
  var nameFilter = searchName.value.trim().toLowerCase();
  var genderFilter = filterGender.value;
  var religionFilter = filterReligion.value;
  var denominationFilter = filterDenomination.value;
  var classFilter = filterClass.value;
  var regionFilter = filterRegion.value;
  var ageFilter = filterAge.value;
  var emergencyFilter = filterEmergency.value.trim();

  var filtered = allStudents.filter(function(student) {
    var nameMatch = student.firstName.toLowerCase().indexOf(nameFilter) > -1 ||
                    (student.middleName && student.middleName.toLowerCase().indexOf(nameFilter) > -1) ||
                    student.surname.toLowerCase().indexOf(nameFilter) > -1;

    var genderMatch = genderFilter === '' || student.gender === genderFilter;
    var religionMatch = religionFilter === '' || student.religion === religionFilter;
    var denominationMatch = denominationFilter === '' || student.denomination === denominationFilter;
    var classMatch = classFilter === '' || student.classApplying === classFilter;
    var regionMatch = regionFilter === '' || student.region === regionFilter;
    var ageMatch = ageFilter === '' || student.age == ageFilter;
    var emergencyMatch = emergencyFilter === '' || (student.emergencyNumber && student.emergencyNumber.indexOf(emergencyFilter) > -1);

    return nameMatch && genderMatch && religionMatch && denominationMatch && classMatch && regionMatch && ageMatch && emergencyMatch;
  });

  renderTable(filtered);
  updateStatistics(filtered);
}

// -------------------- Update Statistics (No Change) --------------------
function updateStatistics(filtered) {
  var total = allStudents.length;
  var males = allStudents.filter(function(s){ return s.gender === 'Male'; }).length;
  var females = allStudents.filter(function(s){ return s.gender === 'Female'; }).length;
  var filteredCount = filtered.length;

  totalStudentsElem.textContent = total;
  totalMalesElem.textContent = males;
  totalFemalesElem.textContent = females;
  filteredResultsElem.textContent = filteredCount;
}


// -------------------- NEW: Add Student Functions --------------------

/**
 * Handles the submission of the new student registration form.
 * @param {Event} e The form submission event.
 */
function handleAddStudent(e) {
    e.preventDefault();

    const firstName = document.getElementById('regFirstName').value.trim();
    const surname = document.getElementById('regSurname').value.trim();
    const classApplying = document.getElementById('regClassApplying').value;
    
    // Basic validation
    if (!firstName || !surname || !classApplying) {
        alert('Please fill in all required fields (First Name, Surname, Class Applying For).');
        return;
    }

    // Collect all data from the form
    const newStudent = {
        firstName: firstName,
        middleName: document.getElementById('regMiddleName').value.trim(),
        surname: surname,
        dob: document.getElementById('regDob').value,
        gender: document.getElementById('regGender').value,
        birthplace: document.getElementById('regBirthplace').value.trim(),
        
        // Handle Denomination Custom Field
        denomination: regDenominationSelect.value === 'Other' ? regDenominationCustom.value.trim() : regDenominationSelect.value,
        religion: document.getElementById('regReligion').value,
        
        // Handle Nationality Custom Field
        nationality: regNationalitySelect.value === 'Other' ? regNationalityCustom.value.trim() : regNationalitySelect.value,
        
        classApplying: classApplying,
        previousSchool: document.getElementById('regPreviousSchool').value.trim(),
        reason: document.getElementById('regReason').value.trim(),

        guardianName: document.getElementById('regGuardianName').value.trim(),
        relationship: document.getElementById('regRelationship').value.trim(),
        occupation: document.getElementById('regOccupation').value.trim(),
        phone: document.getElementById('regPhone').value.trim(),
        email: document.getElementById('regEmail').value.trim(),

        address: document.getElementById('regAddress').value.trim(),
        town: document.getElementById('regTown').value.trim(),
        region: document.getElementById('regRegion').value,

        medical: document.getElementById('regMedical').value.trim(),
        emergencyName: document.getElementById('regEmergencyName').value.trim(),
        emergencyNumber: document.getElementById('regEmergencyNumber').value.trim(),
        
        registrationDate: document.getElementById('regRegistrationDate').value,
    };
    
    // Calculate and add age if DOB is present
    if (newStudent.dob) {
        newStudent.age = calculateAge(newStudent.dob);
    }
    
    // Push the new student object to Firebase
    studentsRef.push(newStudent)
        .then(() => {
            alert("New student registered successfully!");
            addStudentForm.reset(); // Clear the form
            addStudentSection.style.display = 'none'; // Hide the form
            toggleAddStudentFormBtn.textContent = 'Add New Student'; // Reset button text
        })
        .catch(error => {
            alert("Error registering student: " + error.message);
            console.error("Firebase push failed:", error);
        });
}

/**
 * Toggles the visibility of the Add Student form section.
 */
function toggleAddStudentForm() {
    const isHidden = addStudentSection.style.display === 'none';
    addStudentSection.style.display = isHidden ? 'block' : 'none';
    toggleAddStudentFormBtn.textContent = isHidden ? 'Hide Form' : 'Add New Student';
}

/**
 * Handles the display logic for custom fields (Denomination, Nationality).
 */
function handleCustomFieldDisplay(selectElement, customInputElement) {
    customInputElement.style.display = selectElement.value === 'Other' ? 'block' : 'none';
}


// -------------------- Event Listeners (UPDATED) --------------------
searchName.addEventListener('input', applyFilters);
filterGender.addEventListener('change', applyFilters);
filterReligion.addEventListener('change', applyFilters);
filterDenomination.addEventListener('change', applyFilters);
filterClass.addEventListener('change', applyFilters);
filterRegion.addEventListener('change', applyFilters);
filterAge.addEventListener('input', applyFilters);
filterEmergency.addEventListener('input', applyFilters);

clearFiltersBtn.addEventListener('click', function() {
  searchName.value = '';
  filterGender.value = '';
  filterReligion.value = '';
  filterDenomination.value = '';
  filterClass.value = '';
  filterRegion.value = '';
  filterAge.value = '';
  filterEmergency.value = '';
  applyFilters();
});

// NEW: Add Student Event Listeners
if (toggleAddStudentFormBtn) {
    toggleAddStudentFormBtn.addEventListener('click', toggleAddStudentForm);
}
if (addStudentForm) {
    addStudentForm.addEventListener('submit', handleAddStudent);
}
if (regDenominationSelect) {
    regDenominationSelect.addEventListener('change', () => handleCustomFieldDisplay(regDenominationSelect, regDenominationCustom));
}
if (regNationalitySelect) {
    regNationalitySelect.addEventListener('change', () => handleCustomFieldDisplay(regNationalitySelect, regNationalityCustom));
}


// -------------------- Real-time Firebase Listener (UPDATED to capture key) --------------------
studentsRef.on('value', function(snapshot) {
  var data = snapshot.val();
  allStudents = [];
  if (data) {
    // Iterate over keys to get both key (id) and value
    Object.keys(data).forEach(function(key) {
      var student = data[key];
      // Calculate age and store it for consistent filtering/display
      student.age = student.age || calculateAge(student.dob); 
      student.key = key; // Attach the key to the student object
      allStudents.push(student);
    });
  }
  applyFilters();
});

